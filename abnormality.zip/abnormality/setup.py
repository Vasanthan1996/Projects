# setup.py
from setuptools import setup, find_packages

setup(
    name="anomaly-detection-system",
    version="1.0.0",
    author="Manufacturing AI Team",
    description="Comprehensive anomaly detection system for manufacturing quality control",
    packages=find_packages(),
    install_requires=[
        'streamlit==1.32.0',
        'pandas==2.2.1',
        'numpy==1.26.4',
        'scikit-learn==1.4.1',
        'plotly==5.21.0',
        'tensorflow==2.15.0',
        'sqlalchemy==2.0.28',
        'joblib==1.3.2',
        'xgboost==2.0.3',
        'lightgbm==4.3.0',
        'catboost==1.2.5',
        'seaborn==0.13.2',
        'matplotlib==3.8.3',
        'openpyxl==3.1.2',
        'scipy==1.12.0',
        'pyod==1.1.0'
    ],
    python_requires='>=3.8',
)